aws_region = "sa-east-1"

project_name = "modern-data-platform"

environment = "dev"

owner = "Aroldo Brancalhão"

repository = "modern-data-platform"

terraform_state_bucket = "mdp-tfstate-857854758128"