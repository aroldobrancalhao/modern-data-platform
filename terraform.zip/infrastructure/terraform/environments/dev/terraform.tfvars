aws_region = "sa-east-1"

project_name = "mdp"

environment = "dev"

account_id = "857854758128"

owner = "Aroldo Brancalhão"

repository = "modern-data-platform"